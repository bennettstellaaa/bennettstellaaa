export const JSON_URL = null; // "https://ankerdata.netlify.app/dataPro.json"
export const SHEET_ID = "1tdRaVMG9BSry5SpJCH09VkslR1Sc7tPYH4b5m-RJn9c"; // "1tdRaVMG9BSry5SpJCH09VkslR1Sc7tPYH4b5m-RJn9c"
export const TIMEOUT_SEC = 10;
export const THEME = "default-theme-pro";
